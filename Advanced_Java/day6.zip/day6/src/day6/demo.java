package day6;

import java.util.ArrayList;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> list=new ArrayList<String>();    
		list.add("ankit");    
		list.add("nippun");  
		System.out.println(list.size()); 
		int[] array = new int[4];  
		System.out.println("The size of the array is " + array.length);  
		          
	}
	

}
