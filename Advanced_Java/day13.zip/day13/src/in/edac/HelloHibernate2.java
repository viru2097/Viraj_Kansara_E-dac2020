package in.edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Employee;
import in.edac.entity.Person;

public class HelloHibernate2 {
	
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		
		//addEmployee();
		addStudents();
	}
	
	public static void addStudents() {
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Person p1 = new Person("shukla","shukla@gmail.com","120556005");
		Person p2 = new Person("vikru","vikru@gmail.com","1205644455");
		Person p3 = new Person("baru","baru@gmail.com","54548787956");
		Person p4 = new Person("rokdu","rokdu@gmail.com","789456123");
		Person p5 = new Person("viru","viru@gmail.com","123456789");
		
		session.save(p1);
		session.save(p2);
		session.save(p3);
		session.save(p4);
		session.save(p5);
		session.getTransaction().commit();
		session.close();
	}
	
	public static void addEmployee() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Employee std1 = new Employee("cse", "google", "aditya");
		Employee std2 = new Employee("it", "whatsapp", "sumit");
		Employee std3 = new Employee("ece", "tesla", "prafulla");
		Employee std4 = new Employee("ee", "electric car", "meetali");
		Employee std5 = new Employee("me", "tesla adv", "viraj");
		Employee std6 = new Employee("civil", "hyperloop", "priyanka");

		session.save(std1);
		session.save(std2);
		session.save(std3);
		session.save(std4);
		session.save(std5);
		session.save(std6);

		session.getTransaction().commit();
		session.close();
	}

}
