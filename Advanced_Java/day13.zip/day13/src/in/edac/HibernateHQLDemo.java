package in.edac;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Person;

public class HibernateHQLDemo {
	
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	
	public static void main(String[] args) {
		
		
		Session session = sessionFactory.openSession();
		
		String sql = "SELECT * from PERSON";
		
		List<Person>list = session.createNativeQuery(sql,Person.class).list();
		list.stream().map(Person::getName).forEach(System.out::println);
		
	}

}
