package in.edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Employee;
import in.edac.entity.Person;

public class HelloHibernate {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	
	public static void main(String[] args) {
		
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		
		Person p = new Person();
		p.setName("Viraj");
		session.save(p);
		
		
		Employee e = new Employee();
		e.setDepartment("IT");
		session.save(e);
		
		
		session.getTransaction().commit();
		session.close();
	}
}
