package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class HelloWorld {
	
	public static void main(String[] args)  throws Exception{
System.out.println("Hello World");
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/edac", "root", "edac20");
		
		System.out.println(con);
	}

}
