package in.edac;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HelloHibernate {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {

		//createDemo();
		//updateDemo();
		//deleteDemo();
		//singleRead();
		readAll();
	}
	
	public static void readAll() {
		Session session = sessionFactory.openSession();
		
		List<Student> list = session.createQuery("FROM Student",Student.class).list();
		System.out.println(list);
		session.close();
		
	}
	

		public static void singleRead() {
			Session session = sessionFactory.openSession();
			
			Student std = session.find(Student.class,4);
			System.out.println(std);
		}
	
	public static void deleteDemo() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Student std = new Student();
		std.setId(2);
		session.delete(std);
		tx.commit();
		System.out.println("Deleted");
		session.close();
	}
	
	public static void updateDemo() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Student std = new Student();
		std.setId(3);
		std.setEmail("cdac@khargar.in");
		std.setMobile("123456789");
		session.update(std);
		tx.commit();
		System.out.println("Updated");
		session.close();
	}
	
	public static void createDemo() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Student std = new Student();
		std.setUsername("CDAC MUMBAI");
		std.setPassword("INDIA");
		session.save(std);
		tx.commit();
		System.out.println("Inserted");
		session.close();
		
	}

}
