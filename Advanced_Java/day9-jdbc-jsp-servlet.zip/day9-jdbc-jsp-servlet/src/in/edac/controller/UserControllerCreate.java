package in.edac.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.edac.dao.User;
import in.edac.dao.UserDao;

@WebServlet("/user-create")
public class UserControllerCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	try {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		
		UserDao user = new UserDao();
		
		User user_data = new User();
		
		user_data.setUsername(username);
		user_data.setPassword(password);
		user_data.setEmail(email);
		user_data.setMobile(mobile);
		
		user.createUser(user_data);
		
		request.getRequestDispatcher("user-read").forward(request, response);
		
		}
	catch(Exception e) {
	
		e.printStackTrace();
		request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	
	}

}
