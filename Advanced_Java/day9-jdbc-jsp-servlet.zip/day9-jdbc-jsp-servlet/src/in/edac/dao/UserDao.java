package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

public class UserDao {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/user";
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public void checkConnection() {
		
		try (Connection con = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);){
			
			System.out.println("Success Try With Resource");
			
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	
	
	public boolean createUserV1() {
		
		
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);){
			
			String sql = "INSERT INTO USER(USERNAME,PASSWORD,EMAIL,MOBILE) VALUES(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, "Viraj");
			ps.setString(2, "viraj12");
			ps.setString(3, "viraj@gmail.com");
			ps.setString(4, "9632547102");
			ps.executeUpdate();
			System.out.println("Insertion Successfull");
			return true;
		} catch (Exception e) {
	
			e.printStackTrace();
			return false;
		}
		
		
	}
	
	public boolean createUserV2(String username, String password, String email, String mobile) {

		try(Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);) {
			
			String sql = "INSERT INTO USER(USERNAME,PASSWORD,EMAIL,MOBILE) VALUES(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, email);
			ps.setString(4, mobile);
			ps.executeUpdate();
			System.out.println("Insertion Done");
			return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	public boolean createUser(User user) throws Exception {
		
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);) {
			
			String sql = "INSERT INTO USER(username,password,email,mobile) VALUES(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getMobile());
			ps.executeUpdate();
			System.out.println("Inserted Data");
			return true;
			
		} catch (Exception e) {

			e.printStackTrace();
			return false;
		}
		
		
	}
	
	
	public boolean updateUser(User user)  throws Exception{
		Class.forName(DB_DRIVER);
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);){
			
			String sql = "UPDATE USER SET USERNAME=? , PASSWORD=?, EMAIL=?, MOBILE=? WHERE ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getMobile());
			ps.setInt(5,user.getId());
			ps.executeUpdate();
			System.out.println("Data Updated");
			return true;
		} catch (Exception e) {

			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean deleteUser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);) {
			
			String sql = "DELETE FROM USER WHERE ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,user.getId());
			ps.executeUpdate();
			System.out.println("Data Deleted");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public List<User> readAllUser() throws Exception{
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);) {
			
			String sql = "SELECT * FROM USER";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			List<User> list = new ArrayList<User>();
			while(rs.next())
			{
				int colId= rs.getInt("ID");
				String username= rs.getString("USERNAME");
				String password= rs.getString("PASSWORD");
				String email= rs.getString("EMAIL");
				String mobile= rs.getString("MOBILE");
				
				User user = new User();
				user.setId(colId);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);
				user.setMobile(mobile);
				list.add(user);
			}
			return list;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	public static void main(String[] args) throws Exception {
		
		UserDao user = new UserDao();
		//user.checkConnection();
		//user.createUserV1();
		//user.createUserV2("Vaibhav", "1234", "vaibhav@gmail.com", "9874562310");
		
//		User user_data = new User("vikash","vikash12","vikash@gmail.com","98574102");
//		user.createUser(user_data);
//		User user_data = new User("mayuri","mayuri123","mayuri@gmail.com","7894561230");
//		user_data.setId(5);
//		user.updateUser(user_data);
//		User user_data = new User();
//		user_data.setId(5);
//		user.deleteUser(user_data);
		
		List<User> list = user.readAllUser();
		System.out.println(list);
	}

}
